# load packages ------
library(tm)
library(stringi)
library(tokenizers)
library(syuzhet)
library(dplyr)
library(wordcloud)
library(quanteda)

# read in data ------
url <- "https://learn-us-east-1-prod-fleet02-xythos.content.blackboardcdn.com/5fd21eff2f29a/37525949?X-Blackboard-S3-Bucket=learn-us-east-1-prod-fleet01-xythos&X-Blackboard-Expiration=1714208400000&X-Blackboard-Signature=ewUUpAoFzikLfUCNysMX03%2BpTRKSa2jpI6TeIdRSFXM%3D&X-Blackboard-Client-Id=105287&X-Blackboard-S3-Region=us-east-1&response-cache-control=private%2C%20max-age%3D21600&response-content-disposition=inline%3B%20filename%2A%3DUTF-8%27%27TarzanOfTheApes.txt&response-content-type=text%2Fplain&X-Amz-Security-Token=IQoJb3JpZ2luX2VjEIT%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaCXVzLWVhc3QtMSJHMEUCIH%2FPWq7ZT3V%2BnHYEVCTTrlmvr6Kakko0JaUya2OIg8b4AiEAvbJJwHfigsEdS0wvwhhTucFSKnEg%2BHwRX24p2ozWfewqvQUIzf%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FARADGgw2MzU1Njc5MjQxODMiDHdln91nF5bI%2FgUPuiqRBQ4rKmV9yD%2BSdMYxi%2BldnRgqq5G0W5dc9Oy371SAnFBhGktNiwE1dLkBvNNrwN2L6mMx3JoeE87rwXs9h5DT68OfMA6Xoc%2BZFGwCMKyY36Vr2CV42R7H4xJGaCO33E9gsm6YZduDzGo%2B1UpyKRTMXC7xAypSEdl7IhxNNqB683fYbNCwBQG6Hv6lXAOFaACNjXEeYNMnuUCWgawULqlFC4LrYv7%2BNq7ymZ6swfs7BmnKSKX0RC%2BvVbyr9jZ%2BClEseFbucCVM36LHNJY1l1krh6e90r%2BpQrnmyw9ECuAkIcrTKFbPMpxZEfhzL6CGv12tfEBBfMBYH7D60DIhMjl2g1EQmk5Oe1FSjk14AsarYlNVrWfWomrWIcugmXEHc4wZepMqmA4MqefkVCcatkKqorp%2FMe9mvDi8K4H2xv%2BZLVjO%2B6oV8Svz5wK1blZBmnFQe0l%2FEHlT5jqIFJtNxOD1ktgIZBwwJ2PA%2BJ%2Fe%2BITa4n0Xh7veT2pSNMbx6GuxJLYMQG98lEEUIbGm0r4tfczSsg5giZtAB8YCeVPGHGBgpnisogp5FTiXLE4gsquQ3xrgo718ISEqAU8531O5ZLX%2FScxlC82MgWyLCdDfEtUAJ0iiNve2BH1VCUqe%2B7pFngojEk%2FEp6vnquhjr1Enjj1sIECe8nlAcaq1nMJIF93tXYUdfZqMTVbgNl%2FkOHKazEGp%2FlEzkoo9g9Au55QBKfS27SLLLALc21nAI6zsK%2Ba3AzA4jn%2BRmv947vnj80tPY0p4EYSbpgYqFZRDQaCNeN%2BCUc6PLLu71rQhf8Nl87DmSdHEDg0fMta3WG4zkMH%2Fz0jt7k3%2Fz6q2wT37s9OLbpUqYJaO8Tl8VTmaObBp2YY%2F7z0d3DDq5rGxBjqxAdKg4teTqOQ9019n5lr2%2BUzMfkJ%2FBcV1PdFjwTfWiCEhjmsLqswy%2FOYrgwaf%2BAgc8H2D8WPLp6M88Cgs0yvcmp%2F4SvEUF%2B9EqMkNWkJliNRMUTECFaKnQhlO6E3JILhuT3On6U1I01%2BCU7z4ES1UsW3boFjWIGvBxYh%2BndZNcKkyByy1G7jiutFvgKaa0F6nTuJ8xQPTzmjYQeVyyY5ATLvHo23ItST3pd8%2BeoALke5D6A%3D%3D&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20240427T030000Z&X-Amz-SignedHeaders=host&X-Amz-Expires=21600&X-Amz-Credential=ASIAZH6WM4PLSQI6AXMZ%2F20240427%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Signature=72c58834229a8ea11b324db00a9bbe9ba93d919524be30bc078053d00bef3bee"
text <- readLines(url)
df <- data.frame(text)

# separate the chapters into individual files ------

# identify indices for chapters
indx_ch1 <- which(df == "Chapter I", arr.ind=TRUE)
indx_ch2 <- which(df == "Chapter II", arr.ind=TRUE)
indx_ch3 <- which(df == "Chapter III", arr.ind=TRUE)
indx_ch4 <- which(df == "Chapter IV", arr.ind=TRUE)
indx_ch5 <- which(df == "Chapter V", arr.ind=TRUE)
indx_ch6 <- which(df == "Chapter VI", arr.ind=TRUE)
indx_ch7 <- which(df == "Chapter VII", arr.ind=TRUE)
indx_ch8 <- which(df == "Chapter VIII", arr.ind=TRUE)
indx_ch9 <- which(df == "Chapter IX", arr.ind=TRUE)
indx_ch10 <- which(df == "Chapter X", arr.ind=TRUE)
indx_ch11 <- which(df == "Chapter XI", arr.ind=TRUE)
indx_ch12 <- which(df == "Chapter XII", arr.ind=TRUE)
indx_ch13 <- which(df == "Chapter XIII", arr.ind=TRUE)
indx_ch14 <- which(df == "Chapter XIV", arr.ind=TRUE)
indx_ch15 <- which(df == "Chapter XV", arr.ind=TRUE)

# extract the text for chapters
ch1 <- df[(indx_ch1 + 1):(indx_ch2 - 1), ]
ch2 <- df[(indx_ch2 + 1):(indx_ch3 - 1), ]
ch3 <- df[(indx_ch3 + 1):(indx_ch4 - 1), ]
ch4 <- df[(indx_ch4 + 1):(indx_ch5 - 1), ]
ch5 <- df[(indx_ch5 + 1):(indx_ch6 - 1), ]
ch6 <- df[(indx_ch6 + 1):(indx_ch7 - 1), ]
ch7 <- df[(indx_ch7 + 1):(indx_ch8 - 1), ]
ch8 <- df[(indx_ch8 + 1):(indx_ch9 - 1), ]
ch9 <- df[(indx_ch9 + 1):(indx_ch10 - 1), ]
ch10 <- df[(indx_ch10 + 1):(indx_ch11 - 1), ]
ch11 <- df[(indx_ch11 + 1):(indx_ch12 - 1), ]
ch12 <- df[(indx_ch12 + 1):(indx_ch13 - 1), ]
ch13 <- df[(indx_ch13 + 1):(indx_ch14 - 1), ]
ch14 <- df[(indx_ch14 + 1):(indx_ch15 - 1), ]
ch15 <- df[(indx_ch15 + 1):(indx_ch16 - 1), ]

# create a directory for chapters
dir.create("chapters")

# write chapters to the file
write.table(ch1, file = "chapters/chapter1.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch2, file = "chapters/chapter2.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch3, file = "chapters/chapter3.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch4, file = "chapters/chapter4.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch5, file = "chapters/chapter5.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch6, file = "chapters/chapter6.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch7, file = "chapters/chapter7.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch8, file = "chapters/chapter8.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch9, file = "chapters/chapter9.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch10, file = "chapters/chapter10.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch11, file = "chapters/chapter11.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch12, file = "chapters/chapter12.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch13, file = "chapters/chapter13.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch14, file = "chapters/chapter14.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)
write.table(ch15, file = "chapters/chapter15.txt", sep = "\t", row.names = FALSE, col.names = FALSE, quote = FALSE)

# create a VCorpus ------
setwd("/Users/joanne/Documents/Rcode/CSCI6444_P3/Data/chapters")
getwd()
Tarzan <- VCorpus(DirSource(".", ignore.case=FALSE, mode="text"))
str(Tarzan)

# find the top 10 longest words ------
top10_longest_words <- function(doc) {
  text <- content(doc)
  words <- unlist(strsplit(text, "\\W+"))
  words <- unique(Filter(nchar, words))
  longest_words <- words[order(nchar(words), decreasing = TRUE)]
  return(head(longest_words, 10))
}

chapter_longest_words <- list()

for (i in seq_along(Tarzan)) {
  chapter_longest_words[[i]] <- top10_longest_words(Tarzan[[i]])
}

# find the top 10 longest sentences ------
get_top_10_longest_sentences <- function(file_path) {
  text_string <- get_text_as_string(file_path)
  text_get_sentence <- get_sentences(text_string)
  lengths <- nchar(text_get_sentence)
  ordered_indices <- order(lengths, decreasing = TRUE)
  top10_sentences <- text_get_sentence[ordered_indices[1:10]]
  print(top10_sentences)
}

get_top_10_longest_sentences("chapter1.txt")
get_top_10_longest_sentences("chapter2.txt")
get_top_10_longest_sentences("chapter3.txt")
get_top_10_longest_sentences("chapter4.txt")
get_top_10_longest_sentences("chapter5.txt")
get_top_10_longest_sentences("chapter6.txt")
get_top_10_longest_sentences("chapter7.txt")
get_top_10_longest_sentences("chapter8.txt")
get_top_10_longest_sentences("chapter9.txt")
get_top_10_longest_sentences("chapter10.txt")
get_top_10_longest_sentences("chapter11.txt")
get_top_10_longest_sentences("chapter12.txt")
get_top_10_longest_sentences("chapter13.txt")
get_top_10_longest_sentences("chapter14.txt")
get_top_10_longest_sentences("chapter15.txt")

# compute the DTM and TDM ------
TarzanDTM <- DocumentTermMatrix(Tarzan)
inspect(TarzanDTM)
str(TarzanDTM)

TarzanTDM <- TermDocumentMatrix(Tarzan)

# extract texts from the corpus and make it a data frame ------
Ch1 <- Tarzan[[1]]
Ch1_df <- data.frame(Ch1[1])
str(Ch1_df)

# remove numbers and punctuation ------
removeNumPunct <- function(x) {
  gsub("[^[:alpha:][:space:]]+", "", x)
}
TarzanCl <- tm::tm_map(Tarzan, content_transformer(removeNumPunct))
str(TarzanCl)
inspect(TarzanCl)

# converts all characters to lowercase ------
TarzanLow <- tm_map(TarzanCl, tm::content_transformer(tolower))
str(TarzanLow)
inspect(TarzanLow)
Ch1Low <- TarzanLow[[1]]

# compute DTM using TarzanLow ------
TarzanLow_DTM <- DocumentTermMatrix(TarzanLow)
str(TarzanLow_DTM)
inspect(TarzanLow_DTM)
TarzanLow_DTM_matrix <- as.matrix(TarzanLow_DTM)

# remove stop words ------
mystopwords <- c(tm::stopwords("english"))
TarzanStop <- tm::tm_map(TarzanLow, tm::removeWords, mystopwords)
tm::inspect(TarzanStop[[1]])

wordsToRemove <- c("one", "may", "too", "upon", "will", "just", "shall", "even",
                   "much", "quite", "now", "rather", "can", "without", "im", 
                   "youre", "hes", "shes", "its", "were", "theyre", "ive", 
                   "youve", "weve", "theyve", "id", "youd", "hed", "shed", "wed", 
                   "theyd", "ill",  "youll", "hell", "shell", "well", "theyll", 
                   "isnt", "arent", "wasnt", "werent", "hasnt", "havent", "hadnt",
                   "doesnt",  "dont", "didnt", "wont", "wouldnt", "shant", 
                   "shouldnt",  "cant", "couldnt", "mustnt", "lets", "thats", 
                   "whos", "whats", "heres", "theres", "whens", "wheres", "whys",
                   "hows", "whatever", "able", "nothing", "might", "never")
TarzanRemove <- tm::tm_map(TarzanStop, tm::removeWords, wordsToRemove)
tm::inspect(TarzanRemove[[1]])

# create TDM and apply findFreqTerms() ------
TarzanRemove_TDM <- tm::TermDocumentMatrix(TarzanRemove)

freqTerms_5 <- tm::findFreqTerms(TarzanRemove_TDM, lowfreq = 5)
freqTerms_25 <- tm::findFreqTerms(TarzanRemove_TDM, lowfreq = 25)
freqTerms_50 <- tm::findFreqTerms(TarzanRemove_TDM, lowfreq = 50)

nchar(freqTerms_50[11])
freqTerms_50[11]

ch1_termFreq <- tm::termFreq(TarzanRemove[[1]])

tm::inspect(TarzanRemove_TDM)

# draw a dendrogram ------
Ch1_removed_df <- as.data.frame(TarzanRemove_TDM[[1]])
Ch1_removed_Dist <- dist(Ch1_removed_df)
Ch1_removed_DG <- hclust(Ch1_removed_Dist, method = "ward.D2")
str(Ch1_removed_DG)
plot(Ch1_removed_DG)

# remove words and create TDM again ------
newWordsToRemove <- c("back", "saw", "seen", "many", "toward","little", "still", 
                      "beneath", "mighty", "though", "quickly", "must","first",
                      "day", "come", "comes", "came", "found", "ever", "away",
                      "almost", "among", "behind", "far", "instant","knew",
                      "konw","like","last", "another", "new", "next", "thing", 
                      "within", "yet", "thought", "two", "second")
TarzanRemoveNew <- tm::tm_map(TarzanRemove, tm::removeWords, newWordsToRemove)
str(TarzanRemoveNew)

TarzanRemoveNew_TDM <- tm::TermDocumentMatrix(TarzanRemoveNew)
Ch1_newRemoved_df <- as.data.frame(TarzanRemoveNew_TDM[[1]])
Ch1_newRemoved_Dist <- dist(Ch1_newRemoved_df)
Ch1_newRemoved_DG <- hclust(Ch1_newRemoved_Dist, method = "ward.D2")
str(Ch1_newRemoved_DG)
plot(Ch1_newRemoved_DG)

# word cloud ------
ch1_newTermFreq <- tm::termFreq(TarzanRemoveNew[[1]])
ch1.words <- names(ch1_newTermFreq)

pal <- brewer.pal(9,"BuGn")
str(pal)
ch1.wc <- wordcloud(ch1.words, ch1_newTermFreq, colors = pal[-(1:4)])

pal2 <- brewer.pal(9,"Spectral")
ch1.wc2 <- wordcloud(ch1.words, ch1_newTermFreq, colors = pal2)

# quanteda ------
TarzanCl_ch1 <- TarzanCl[[1]]
TarzanCl_ch1$content[1:15]

# remove blank lines
removeBlankLines <- function(x) {
  lines <- unlist(strsplit(as.character(x), "\n"))
  non_blank_lines <- lines[nchar(trimws(lines)) > 0]
  return(paste(non_blank_lines))
}
TarzanCl_noBlankL <- tm_map(TarzanCl, content_transformer(removeBlankLines))

TarzanCl_ch1_noBlankL <- TarzanCl_noBlankL[[1]]
TarzanCl_ch1_noBlankL$content[1:11]

# token
ch1_ClnoBlankL_tokens <- quanteda::tokens(TarzanCl_ch1_noBlankL$content) 
str(ch1_ClnoBlankL_tokens)

# DFM
ch1_ClnoBlankL_DFM <- quanteda::dfm(ch1_ClnoBlankL_tokens)
str(ch1_ClnoBlankL_DFM)

# get the frequency of terms in the DFM
ch1_ClnoBlankL_DFMFreq <- quanteda::docfreq(ch1_ClnoBlankL_DFM)
str(ch1_ClnoBlankL_DFMFreq)

# assign weights
ch1_ClnoBlankL_Weight <- quanteda::dfm_weight(ch1_ClnoBlankL_DFM)
str(ch1_ClnoBlankL_Weight)

# tf-idf score
ch1_ClnoBlankL_TFIDF <- quanteda::dfm_tfidf(ch1_ClnoBlankL_DFM, scheme_tf = "count", scheme_df = "inverse")
str(ch1_ClnoBlankL_TFIDF)

# syuzhet ------
TarzanCh1_DF <- as.data.frame(Tarzan[[1]]$content)

TarzanCh1_string <- get_text_as_string("chapter1.txt")

TarzanCh1_sentences <- get_sentences(TarzanCh1_string)
str(TarzanCh1_sentences)

TarzanCh1_sentiSyuzhet <- get_sentiment(TarzanCh1_sentences, "syuzhet")
TarzanCh1_sentiBing <- get_sentiment(TarzanCh1_sentences, "bing")

TarzanCh1DictionSyu <- get_sentiment_dictionary()
TarzanCh1DictionBing <- get_sentiment_dictionary("bing")

TarzanCh1_sentiSyu_sum <- sum(TarzanCh1_sentiSyuzhet)
TarzanCh1_sentiBing_sum <- sum(TarzanCh1_sentiBing)

TarzanCh1_sentiSyu_mean <- mean(TarzanCh1_sentiSyuzhet)
TarzanCh1_sentiBing_mean <- mean(TarzanCh1_sentiBing)

summary(TarzanCh1_sentiSyuzhet) 
summary(TarzanCh1_sentiBing) 

TarzanCh1_nrcSenti <- get_nrc_sentiment(TarzanCh1_sentences)
TarzanCh1_counts <- colSums(TarzanCh1_nrcSenti)

plot(TarzanCh1_sentiSyuzhet, main="TarzanoftheApesCh1 Plot Trajectory", 
     xlab = "Narrative", ylab = "Emotional valence")


plot(TarzanCh1_sentiBing, main="TarzanoftheApesCh1 Plot Trajectory: Bing", 
     xlab = "Narrative", ylab = "Emotional valence")

TarzanCh1_sentiSyuz_pctValue <- get_percentage_values(TarzanCh1_sentiSyuzhet, bins = 10)
structure(TarzanCh1_sentiSyuz_pctValue)
plot(TarzanCh1_sentiSyuz_pctValue, main="TarzanoftheApesCh1 PCTValue 10 Bins", 
     xlab = "Narrative", ylab = "Emotional valence", col = "red")

TarzanCh1_sentiSyuz_pctValue20 <- get_percentage_values(TarzanCh1_sentiSyuzhet, bins = 20)
structure(TarzanCh1_sentiSyuz_pctValue20)
plot(TarzanCh1_sentiSyuz_pctValue20, main="TarzanoftheApesCh1 PCTValue 20 Bins", 
     xlab = "Narrative", ylab = "Emotional valence", col = "blue")


