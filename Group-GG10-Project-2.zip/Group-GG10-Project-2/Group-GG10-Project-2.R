# load packages --------
library(igraph)
library(ggplot2)
library(GGally)
library(corrplot)
library(sna)
library(psych)
library(caret)
library(factoextra)
library(class)
library(gmodels)

# read in data ------
data <- read.csv("/Users/joanne/Downloads/ObesityDataSet_raw_and_data_sinthetic.csv")

# change chr to num --------
data$Gender <- ifelse(data$Gender == "Female", 1, 0) #Female: 1, Male: 0
data$family_history_with_overweight <- ifelse(data$family_history_with_overweight == "yes", 1, 0) #yes: 1, no: 0
data$FAVC <- ifelse(data$FAVC == "yes", 1, 0) #yes: 1, no: 0
data$CAEC <- with(data, ifelse(CAEC == "Sometimes", 1,
                        ifelse(CAEC == "Frequently", 2,
                        ifelse(CAEC == "Always", 3,
                        ifelse(CAEC == "no", 0, NA)))))
data$SMOKE <- ifelse(data$SMOKE == "yes", 1, 0) #yes: 1, no: 0
data$SCC <- ifelse(data$SCC == "yes", 1, 0) #yes: 1, no: 0
data$CALC <- with(data, ifelse(CALC == "Sometimes", 1,
                        ifelse(CALC == "Frequently", 2,
                        ifelse(CALC == "Always", 3,
                        ifelse(CALC == "no", 0, NA)))))
data$MTRANS <- with(data, ifelse(MTRANS == "Public_Transportation", 1,
                          ifelse(MTRANS == "Bike", 2,
                          ifelse(MTRANS == "Motorbike", 3,
                          ifelse(MTRANS == "Automobile", 4,
                          ifelse(MTRANS == "Walking", 0, NA))))))
data$NObeyesdad <- with(data, ifelse(NObeyesdad == "Overweight_Level_I", 1,
                              ifelse(NObeyesdad == "Overweight_Level_II", 2,
                              ifelse(NObeyesdad == "Obesity_Type_I", 3,
                              ifelse(NObeyesdad == "Insufficient_Weight", 4,
                              ifelse(NObeyesdad == "Obesity_Type_II", 5,
                              ifelse(NObeyesdad == "Obesity_Type_III", 6,
                              ifelse(NObeyesdad == "Normal_Weight", 0, NA))))))))
# explore --------
str(data)
summary(data)
describe(data)

# plot --------
pairs(data)
corr_matrix <- cor(data)
corrplot(corr_matrix, method = "color", tl.col = "black", addCoef.col = "black", number.cex = 0.5)

# eliminate features --------
data <- subset(data, select = -c(Height, MTRANS, Age, SMOKE, CH2O, TUE))

# normalize the data --------
normalized_data <- as.data.frame(scale(data))

# extract cluster object --------
extract.objects <- function(kmeans_result, original_data, cluster_number) {
  cluster_indices <- which(kmeans_result$cluster == cluster_number)
  
  cluster_data <- original_data[cluster_indices, ]
  
  return(cluster_data)
}

# cluster on the dataset --------
set.seed(123)
# k = 2
data.k2 <- kmeans(normalized_data, centers = 2)
str(data.k2)
factoextra::fviz_cluster(data.k2, data = normalized_data)

extract.c1 <- extract.objects(data.k2, data, 1)
extract.c2 <- extract.objects(data.k2, data, 2)
object10.c1 <- data[10, ]
object39.c2 <- data[39, ]

data.k2$centers

# k = 3
data.k3 <- kmeans(normalized_data, centers = 3)
str(data.k3)
factoextra::fviz_cluster(data.k3, data = normalized_data)

extract.c1 <- extract.objects(data.k3, data, 1)
extract.c2 <- extract.objects(data.k3, data, 2)
extract.c3 <- extract.objects(data.k3, data, 3)

object226.c1 <- data[226, ]
object457.c3 <- data[457, ]

object195.c2 <- data[195, ]
object388.c3 <- data[388, ]

data.k3$centers

# k = 5
data.k5 <- kmeans(normalized_data, centers = 5)
str(data.k5)
factoextra::fviz_cluster(data.k5, data = normalized_data)

extract.c1 <- extract.objects(data.k5, data, 1)
extract.c2 <- extract.objects(data.k5, data, 2)
extract.c3 <- extract.objects(data.k5, data, 3)
extract.c4 <- extract.objects(data.k5, data, 4)
extract.c5 <- extract.objects(data.k5, data, 5)

data.k5$centers

# k = 7
data.k7 <- kmeans(normalized_data, centers = 7)
str(data.k7)
factoextra::fviz_cluster(data.k7, data = normalized_data)


extract.c1 <- extract.objects(data.k7, data, 1)
extract.c2 <- extract.objects(data.k7, data, 2)
extract.c3 <- extract.objects(data.k7, data, 3)
extract.c4 <- extract.objects(data.k7, data, 4)
extract.c5 <- extract.objects(data.k7, data, 5)
extract.c6 <- extract.objects(data.k7, data, 6)
extract.c7 <- extract.objects(data.k7, data, 7)

data.k7$centers

# k = 9
data.k9 <- kmeans(normalized_data, centers = 9)
str(data.k9)
factoextra::fviz_cluster(data.k9, data = normalized_data)

data.k9$centers

# k = 11
data.k11 <- kmeans(normalized_data, centers = 11)
str(data.k11)
factoextra::fviz_cluster(data.k11, data = normalized_data)

data.k11$centers

# k = 13
data.k13 <- kmeans(normalized_data, centers = 13)
str(data.k13)
factoextra::fviz_cluster(data.k13, data = normalized_data)

data.k13$centers

# k = 15
data.k15 <- kmeans(normalized_data, centers = 15)
str(data.k15)
factoextra::fviz_cluster(data.k15, data = normalized_data)

data.k15$centers

# add cluster to the data
data_with_clusters <- data
data_with_clusters$Cluster <- data.k5$cluster

# fviz_nbclust()
factoextra::fviz_nbclust(normalized_data, FUNcluster = kmeans, method = "wss", 
                         k.max = 15, verbose = TRUE)

# split the dataset --------
# 70-30%
set.seed(123) 
trainIndex70 <- createDataPartition(normalized_data$NObeyesdad, p = .70, list = FALSE)
train70 <- normalized_data[trainIndex70, ]
test30 <- normalized_data[-trainIndex70, ]

# 60-40%
set.seed(123)
trainIndex60 <- createDataPartition(normalized_data$NObeyesdad, p = .60, list = FALSE)
train60 <- normalized_data[trainIndex60, ]
test40 <- normalized_data[-trainIndex60, ]

# 50-50%
set.seed(123)
trainIndex50 <- createDataPartition(normalized_data$NObeyesdad, p = .50, list = FALSE)
train50 <- normalized_data[trainIndex50, ]
test50 <- normalized_data[-trainIndex50, ]

# performance function --------
calculate_performance <- function(matrix) {
  TP <- sum(diag(matrix)) 
  FP <- sum(matrix) - TP  

  Precision <- TP / (TP + FP)
  FDR <- FP / (TP + FP) #False Discovery Rates
  
  result_matrix <- matrix(c(TP, FP, Precision, FDR), nrow = 1,
                          dimnames = list("Values", c("TP", "FP", "Precision", "False Discovery Rates")))
  
  return(result_matrix)
}

# 70-30% dataset --------
set.seed(123)
# k = 5 --------
# K-NN
train70.k5 = kmeans(train70, centers = 5)
test30.k5 = knn(train70, test30, train70.k5$cluster, k = 5)
test30.k5.kmean = kmeans(test30, centers = 5)
test30.k5.labels = test30.k5.kmean$cluster
length(test30.k5.labels)

# glm()
train70.glm.k5 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                  + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                  family = gaussian, data = train70)
summary(train70.glm.k5)

train70.glm.anova.k5 = anova(train70.glm.k5, test = "Chisq")

plot(train70.glm.k5)

# predict
test30.predict.k5 = predict(train70.glm.k5, newdata = test30)
summary(test30.predict.k5)

# confident interval
confint(train70.glm.k5)

# compare actual vs. prediction 
test30.predict.kmeans.k5 = kmeans(test30.predict.k5, centers = 5)
test30.ct.k5 = CrossTable(test30.predict.kmeans.k5$cluster, test30.k5.kmean$cluster, prop.chisq = TRUE)

# performance measures
test30.conf_matrix.k5 <- table(factor(test30.k5.kmean$cluster), factor(test30.predict.kmeans.k5$cluster))
calculate_performance(test30.conf_matrix.k5)

# plot
plot(test30$NObeyesdad, test30.predict.k5, 
     xlab = "test30$NObeyesdad", 
     ylab = "test30.predict.k5", 
     main = "Plotting test30$NObeyesdad versus test30.predict.k5")

# k = 7 --------
# K-NN
train70.k7 = kmeans(train70, centers = 7)
test30.k7 = knn(train70, test30, train70.k7$cluster, k = 7)
test30.k7.kmean = kmeans(test30, centers = 7)
test30.k7.labels = test30.k7.kmean$cluster
length(test30.k7.labels)

# glm()
train70.glm.k7 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                     + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                     family = gaussian, data = train70)
summary(train70.glm.k7)

train70.glm.anova.k7 = anova(train70.glm.k7, test = "Chisq")

plot(train70.glm.k7)

# predict
test30.predict.k7 = predict(train70.glm.k7, newdata = test30)
summary(test30.predict.k7)

# confident interval
confint(train70.glm.k7)

# compare actual vs. prediction 
test30.predict.kmeans.k7 = kmeans(test30.predict.k7, centers = 7)
test30.ct.k7 = CrossTable(test30.predict.kmeans.k7$cluster, test30.k7.kmean$cluster, prop.chisq = TRUE)

# performance measures
test30.conf_matrix.k7 <- table(factor(test30.k7.kmean$cluster), factor(test30.predict.kmeans.k7$cluster))
calculate_performance(test30.conf_matrix.k7)

# k = 9 --------
# K-NN
train70.k9 = kmeans(train70, centers = 9)
test30.k9 = knn(train70, test30, train70.k9$cluster, k = 9)
test30.k9.kmean = kmeans(test30, centers = 9)
test30.k9.labels = test30.k9.kmean$cluster
length(test30.k9.labels)

# glm()
train70.glm.k9 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                     + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                     family = gaussian, data = train70)
summary(train70.glm.k9)

train70.glm.anova.k9 = anova(train70.glm.k9, test = "Chisq")

plot(train70.glm.k9)

# predict
test30.predict.k9 = predict(train70.glm.k9, newdata = test30)
summary(test30.predict.k9)

# confident interval
confint(train70.glm.k9)

# compare actual vs. prediction 
test30.predict.kmeans.k9 = kmeans(test30.predict.k9, centers = 9)
test30.ct.k9 = CrossTable(test30.predict.kmeans.k9$cluster, test30.k9.kmean$cluster, prop.chisq = TRUE)

# performance measures
test30.conf_matrix.k9 <- table(factor(test30.k9.kmean$cluster), factor(test30.predict.kmeans.k9$cluster))
calculate_performance(test30.conf_matrix.k9)

# k = 11 --------
# K-NN
train70.k11 = kmeans(train70, centers = 11)
test30.k11 = knn(train70, test30, train70.k11$cluster, k = 11)
test30.k11.kmean = kmeans(test30, centers = 11)
test30.k11.labels = test30.k11.kmean$cluster
length(test30.k11.labels)

# glm()
train70.glm.k11 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                     + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                     family = gaussian, data = train70)
summary(train70.glm.k11)

train70.glm.anova.k11 = anova(train70.glm.k11, test = "Chisq")

plot(train70.glm.k11)

# predict
test30.predict.k11 = predict(train70.glm.k11, newdata = test30)
summary(test30.predict.k11)

# confident interval
confint(train70.glm.k11)

# compare actual vs. prediction 
test30.predict.kmeans.k11 = kmeans(test30.predict.k11, centers = 11)
test30.ct.k11 = CrossTable(test30.predict.kmeans.k11$cluster, test30.k11.kmean$cluster, prop.chisq = TRUE)

# performance measures
test30.conf_matrix.k11 <- table(factor(test30.k11.kmean$cluster), factor(test30.predict.kmeans.k11$cluster))
calculate_performance(test30.conf_matrix.k11)



# 60-40% dataset --------
set.seed(123)
# k = 5 --------
# K-NN
train60.k5 = kmeans(train60, centers = 5)
test40.k5 = knn(train60, test40, train60.k5$cluster, k = 5)
test40.k5.kmean = kmeans(test40, centers = 5)
test40.k5.labels = test40.k5.kmean$cluster
length(test40.k5.labels)

# glm()
train60.glm.k5 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                     + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                     family = gaussian, data = train60)
summary(train60.glm.k5)

train60.glm.anova.k5 = anova(train60.glm.k5, test = "Chisq")

plot(train60.glm.k5)

# predict
test40.predict.k5 = predict(train60.glm.k5, newdata = test40)
summary(test40.predict.k5)

# confident interval
confint(train60.glm.k5)

# compare actual vs. prediction 
test40.predict.kmeans.k5 = kmeans(test40.predict.k5, centers = 5)
test40.ct.k5 = CrossTable(test40.predict.kmeans.k5$cluster, test40.k5.kmean$cluster, prop.chisq = TRUE)

# performance measures
test40.conf_matrix.k5 <- table(factor(test40.k5.kmean$cluster), factor(test40.predict.kmeans.k5$cluster))
calculate_performance(test40.conf_matrix.k5)

# plot
plot(test40$NObeyesdad, test40.predict.k5, 
     xlab = "test40$NObeyesdad", 
     ylab = "test40.predict.k5", 
     main = "Plotting test40$NObeyesdad versus test40.predict.k5")

# k = 7 --------
# K-NN
train60.k7 = kmeans(train60, centers = 7)
test40.k7 = knn(train60, test40, train60.k7$cluster, k = 7)
test40.k7.kmean = kmeans(test40, centers = 7)
test40.k7.labels = test40.k7.kmean$cluster
length(test40.k7.labels)

# glm()
train60.glm.k7 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                     + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                     family = gaussian, data = train60)
summary(train60.glm.k7)

train60.glm.anova.k7 = anova(train60.glm.k7, test = "Chisq")

plot(train60.glm.k7)

# predict
test40.predict.k7 = predict(train60.glm.k7, newdata = test40)
summary(test40.predict.k7)

# confident interval
confint(train60.glm.k7)

# compare actual vs. prediction 
test40.predict.kmeans.k7 = kmeans(test40.predict.k7, centers = 7)
test40.ct.k7 = CrossTable(test40.predict.kmeans.k7$cluster, test40.k7.kmean$cluster, prop.chisq = TRUE)

# performance measures
test40.conf_matrix.k7 <- table(factor(test40.k7.kmean$cluster), factor(test40.predict.kmeans.k7$cluster))
calculate_performance(test40.conf_matrix.k7)

# k = 9 --------
# K-NN
train60.k9 = kmeans(train60, centers = 9)
test40.k9 = knn(train60, test40, train60.k9$cluster, k = 9)
test40.k9.kmean = kmeans(test40, centers = 9)
test40.k9.labels = test40.k9.kmean$cluster
length(test40.k9.labels)

# glm()
train60.glm.k9 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                     + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                     family = gaussian, data = train60)
summary(train60.glm.k9)

train60.glm.anova.k9 = anova(train60.glm.k9, test = "Chisq")

plot(train60.glm.k9)

# predict
test40.predict.k9 = predict(train60.glm.k9, newdata = test40)
summary(test40.predict.k9)

# confident interval
confint(train60.glm.k9)

# compare actual vs. prediction 
test40.predict.kmeans.k9 = kmeans(test40.predict.k9, centers = 9)
test40.ct.k9 = CrossTable(test40.predict.kmeans.k9$cluster, test40.k9.kmean$cluster, prop.chisq = TRUE)

# performance measures
test40.conf_matrix.k9 <- table(factor(test40.k9.kmean$cluster), factor(test40.predict.kmeans.k9$cluster))
calculate_performance(test40.conf_matrix.k9)

# k = 11 --------
# K-NN
train60.k11 = kmeans(train60, centers = 11)
test40.k11 = knn(train60, test40, train60.k11$cluster, k = 11)
test40.k11.kmean = kmeans(test40, centers = 11)
test40.k11.labels = test40.k11.kmean$cluster
length(test40.k11.labels)

# glm()
train60.glm.k11 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                      + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                      family = gaussian, data = train60)
summary(train60.glm.k11)

train60.glm.anova.k11 = anova(train60.glm.k11, test = "Chisq")

plot(train60.glm.k11)

# predict
test40.predict.k11 = predict(train60.glm.k11, newdata = test40)
summary(test40.predict.k11)

# confident interval
confint(train60.glm.k11)

# compare actual vs. prediction 
test40.predict.kmeans.k11 = kmeans(test40.predict.k11, centers = 11)
test40.ct.k11 = CrossTable(test40.predict.kmeans.k11$cluster, test40.k11.kmean$cluster, prop.chisq = TRUE)

# performance measures
test40.conf_matrix.k11 <- table(factor(test40.k11.kmean$cluster), factor(test40.predict.kmeans.k11$cluster))
calculate_performance(test40.conf_matrix.k11)


# 50-50% dataset --------
set.seed(123)
# k = 5 --------
# K-NN
train50.k5 = kmeans(train50, centers = 5)
test50.k5 = knn(train50, test50, train50.k5$cluster, k = 5)
test50.k5.kmean = kmeans(test50, centers = 5)
test50.k5.labels = test50.k5.kmean$cluster
length(test50.k5.labels)

# predict
test50.predict.k5 = predict(train50.glm.k5, newdata = test50)
summary(test50.predict.k5)

# confident interval
confint(train50.glm.k5)

# compare actual vs. prediction 
test50.predict.kmeans.k5 = kmeans(test50.predict.k5, centers = 5)
test50.ct.k5 = CrossTable(test50.predict.kmeans.k5$cluster, test50.k5.kmean$cluster, prop.chisq = TRUE)

# performance measures
test50.conf_matrix.k5 <- table(factor(test50.k5.kmean$cluster), factor(test50.predict.kmeans.k5$cluster))
calculate_performance(test50.conf_matrix.k5)

# plot
plot(test50$NObeyesdad, test50.predict.k5, 
     xlab = "test50$NObeyesdad", 
     ylab = "test50.predict.k5", 
     main = "Plotting test50$NObeyesdad versus test50.predict.k5")

# k = 7 --------
# K-NN
train50.k7 = kmeans(train50, centers = 7)
test50.k7 = knn(train50, test50, train50.k7$cluster, k = 7)
test50.k7.kmean = kmeans(test50, centers = 7)
test50.k7.labels = test50.k7.kmean$cluster
length(test50.k7.labels)

# glm()
train50.glm.k7 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                     + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                     family = gaussian, data = train50)
summary(train50.glm.k7)

train60.glm.anova.k7 = anova(train50.glm.k7, test = "Chisq")

plot(train50.glm.k7)

# predict
test50.predict.k7 = predict(train50.glm.k7, newdata = test50)
summary(test50.predict.k7)

# confident interval
confint(train50.glm.k7)

# compare actual vs. prediction 
test50.predict.kmeans.k7 = kmeans(test50.predict.k7, centers = 7)
test50.ct.k7 = CrossTable(test50.predict.kmeans.k7$cluster, test50.k7.kmean$cluster, prop.chisq = TRUE)

# performance measures
test50.conf_matrix.k7 <- table(factor(test50.k7.kmean$cluster), factor(test50.predict.kmeans.k7$cluster))
calculate_performance(test50.conf_matrix.k7)

# k = 9 --------
# K-NN
train50.k9 = kmeans(train50, centers = 9)
test50.k9 = knn(train50, test50, train50.k9$cluster, k = 9)
test50.k9.kmean = kmeans(test50, centers = 9)
test50.k9.labels = test50.k9.kmean$cluster
length(test50.k9.labels)

# glm()
train50.glm.k9 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                     + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                     family = gaussian, data = train50)
summary(train50.glm.k9)

train50.glm.anova.k9 = anova(train50.glm.k9, test = "Chisq")

plot(train50.glm.k9)

# predict
test50.predict.k9 = predict(train50.glm.k9, newdata = test50)
summary(test50.predict.k9)

# confident interval
confint(train50.glm.k9)

# compare actual vs. prediction 
test50.predict.kmeans.k9 = kmeans(test50.predict.k9, centers = 9)
test50.ct.k9 = CrossTable(test50.predict.kmeans.k9$cluster, test50.k9.kmean$cluster, prop.chisq = TRUE)

# performance measures
test50.conf_matrix.k9 <- table(factor(test50.k9.kmean$cluster), factor(test50.predict.kmeans.k9$cluster))
calculate_performance(test50.conf_matrix.k9)

# k = 11 --------
# K-NN
train50.k11 = kmeans(train50, centers = 11)
test50.k11 = knn(train50, test50, train50.k11$cluster, k = 11)
test50.k11.kmean = kmeans(test50, centers = 11)
test50.k11.labels = test50.k11.kmean$cluster
length(test50.k11.labels)

# glm()
train50.glm.k11 = glm(NObeyesdad ~ Gender + Weight + family_history_with_overweight 
                      + FAVC + FCVC + NCP + CAEC + SCC + FAF + CALC, 
                      family = gaussian, data = train50)
summary(train50.glm.k11)

train50.glm.anova.k11 = anova(train50.glm.k11, test = "Chisq")

plot(train50.glm.k11)

# predict
test50.predict.k11 = predict(train50.glm.k11, newdata = test50)
summary(test50.predict.k11)

# confident interval
confint(train50.glm.k11)

# compare actual vs. prediction 
test50.predict.kmeans.k11 = kmeans(test50.predict.k11, centers = 11)
test50.ct.k11 = CrossTable(test50.predict.kmeans.k11$cluster, test50.k11.kmean$cluster, prop.chisq = TRUE)

# performance measures
test50.conf_matrix.k11 <- table(factor(test50.k11.kmean$cluster), factor(test50.predict.kmeans.k11$cluster))
calculate_performance(test50.conf_matrix.k11)



